package com.cookandroid.todolist.memo

import android.content.Context

class MemoRepository(context: Context) {
    private val memoDao: MemoDao

    init {
        val memoDatabase = MemoDatabase.getDatabase(context)
        memoDao = memoDatabase.memoDao()
    }

    fun allMemo() = memoDao.getAllMemos()

    fun getMemo(memoId: Long) = memoDao.getMemo(memoId)

    fun addMemo(content: String) {
        val memo = MemoEntity(memoContent = content)
        memoDao.addMemo(memo)
    }

    fun updateMemo(id: Long, content: String) {
        val memo = MemoEntity(id, content)
        memoDao.updateMemo(memo)
    }

    fun deleteMemo(memoId: Long) {
        memoDao.deleteMemo(memoId)
    }
}
