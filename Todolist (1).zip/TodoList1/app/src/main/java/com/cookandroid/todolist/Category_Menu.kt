package com.cookandroid.todolist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.cookandroid.todolist.R

class Category_Menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_menu)
    }
}