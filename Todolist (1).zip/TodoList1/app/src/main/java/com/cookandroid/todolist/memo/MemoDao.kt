package com.cookandroid.todolist.memo

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface MemoDao {

    @Query("SELECT * FROM memo_table")
    fun getAllMemos(): LiveData<List<MemoEntity>>

    @Query("SELECT * FROM memo_table WHERE id = :memoId")
    fun getMemo(memoId: Long): LiveData<MemoEntity?>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun addMemo(memo: MemoEntity)

    @Update
    fun updateMemo(memo: MemoEntity)

    @Query("DELETE FROM memo_table WHERE id = :memoId")
    fun deleteMemo(memoId: Long)
}

