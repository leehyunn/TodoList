package com.cookandroid.todolist.memo

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cookandroid.todolist.R
import com.cookandroid.todolist.databinding.ActivityMemoBinding
import com.cookandroid.todolist.databinding.ItemMemoBinding

class MemoActivity : AppCompatActivity() {
    private val binding by lazy { ActivityMemoBinding.inflate(layoutInflater) }
    private val viewModel: MemoViewModel by viewModels()
    private val adapter by lazy { MemoListAdapter() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        initUi()
    }

    private fun initUi() = with(binding) {
        toolbar.run {
            setNavigationOnClickListener { finish() }
            setOnMenuItemClickListener {
                if (it.itemId == R.id.action_add) {
                    startActivity(Intent(this@MemoActivity, MemoEditorActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    })
                }

                return@setOnMenuItemClickListener true
            }
        }

        adapter.onItemClickListener = {
            startActivity(Intent(this@MemoActivity, MemoEditorActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("memo", it)
            })
        }

        recyclerView.run {
            this.adapter = this@MemoActivity.adapter
            addItemDecoration(
                DividerItemDecoration(
                    this@MemoActivity,
                    LinearLayoutManager.VERTICAL
                )
            )
        }

        viewModel.allMemo().observe(this@MemoActivity) {
            adapter.submitList(it)

            emptyView.isVisible = it.isEmpty()
        }
    }

    private class MemoListAdapter
        : ListAdapter<MemoEntity, MemoListAdapter.MemoItemViewHolder>(diffUtil) {
        var onItemClickListener: ((MemoEntity) -> Unit)? = null

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MemoItemViewHolder {
            val layoutInflater = LayoutInflater.from(parent.context)
            val binding = ItemMemoBinding.inflate(layoutInflater, parent, false)
            return MemoItemViewHolder(binding)
        }

        override fun onBindViewHolder(holder: MemoItemViewHolder, position: Int) {
            val item = getItem(position)

            with(holder.binding) {
                root.setOnClickListener {
                    onItemClickListener?.invoke(item)
                }

                memoTextView.text = item.memoContent
            }
        }

        class MemoItemViewHolder(val binding: ItemMemoBinding) :
            RecyclerView.ViewHolder(binding.root)

        companion object {
            val diffUtil = object : DiffUtil.ItemCallback<MemoEntity>() {
                override fun areItemsTheSame(oldItem: MemoEntity, newItem: MemoEntity): Boolean {
                    return oldItem.memoID == newItem.memoID
                }

                override fun areContentsTheSame(oldItem: MemoEntity, newItem: MemoEntity): Boolean {
                    return oldItem.memoContent == newItem.memoContent
                }
            }
        }
    }
}