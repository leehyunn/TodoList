package com.cookandroid.todolist

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Priority_Select : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_priority_select)
    }
}