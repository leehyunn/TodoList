package com.cookandroid.todolist.memo

import android.app.Application
import androidx.lifecycle.AndroidViewModel

class MemoViewModel(application: Application) : AndroidViewModel(application) {
    private val memoRepository by lazy { MemoRepository(application) }

    fun allMemo() = memoRepository.allMemo()

    fun getMemo(memoId: Long) = memoRepository.getMemo(memoId)

    fun addMemo(content: String) {
        memoRepository.addMemo(content)
    }

    fun updateMemo(id: Long, content: String) {
        memoRepository.updateMemo(id, content)
    }

    fun deleteMemo(memoId: Long) {
        memoRepository.deleteMemo(memoId)
    }
}
