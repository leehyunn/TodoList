package com.cookandroid.todolist.memo


import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.cookandroid.todolist.databinding.ActivityMemoEditorBinding


class MemoEditorActivity : AppCompatActivity() {
    private val binding by lazy { ActivityMemoEditorBinding.inflate(layoutInflater) }
    private val viewModel by viewModels<MemoViewModel>()
    private var memo: MemoEntity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        memo = intent?.getParcelableExtra("memo")
        if (savedInstanceState != null) memo = savedInstanceState.getParcelable("memo")

        setContentView(binding.root)

        initUi()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putParcelable("memo", memo)
        super.onSaveInstanceState(outState)
    }

    private fun initUi() = with(binding) {
        memo?.let {
            memoContent.setText(it.memoContent)
        }

        deleteButton.run {
            isVisible = memo != null

            setOnClickListener {
                viewModel.deleteMemo(memo!!.memoID)
                finish()
            }
        }

        memoConfirmButton.setOnClickListener {
            val content = binding.memoContent.text.toString()

            if (memo != null) {
                viewModel.updateMemo(memo!!.memoID, content)
            } else {
                viewModel.addMemo(content)
            }

            finish()
        }

        binding.back6.setOnClickListener { finish() }
    }
}
